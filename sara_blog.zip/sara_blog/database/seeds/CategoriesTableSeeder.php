<?php

use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $world = \App\Category::create([
            'name' => 'World',
        ]);

        $politics = \App\Category::create([
            'name' => 'Politics',
        ]);

        $travel = \App\Category::create([
            'name' => 'Travel',
        ]);

        $sport = \App\Category::create([
            'name' => 'Sport',
        ]);

        $photography = \App\Category::create([
            'name' => 'Photography',
        ]);

        $health = \App\Category::create([
            'name' => 'Health',
        ]);

        $lifestyle = \App\Category::create([
            'name' => 'Lifestyle',
        ]);

        $fashion = \App\Category::create([
            'name' => 'Fashion',
        ]);

        $recipes = \App\Category::create([
            'name' => 'Recipes',
        ]);

        $news = \App\Category::create([
            'name' => 'News',
        ]);

        $books = \App\Category::create([
            'name' => 'Books',
        ]);

    }
}