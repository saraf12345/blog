<?php $__env->startSection('content'); ?>

    <?php if(request()->category): ?>
        <div class="container">
            <div class="m-auto text-center border rounded p-3 bg-white">
                <p class="text-info font-italic">Posts of category: </p>
                <h1 class="text-secondary font-italic"><?php echo e(request()->category); ?></h1>
            </div>
            <br>
        </div>
        <post-index category="<?php echo e(request()->category); ?>"></post-index>
    <?php elseif(request()->user): ?>
        <div class="container">
            <div class="m-auto text-center border rounded p-3 bg-white">
                <p class="text-info font-italic">Posts of user: </p>
                <h1 class="text-secondary font-italic"><?php echo e(request()->user); ?></h1>
            </div>
            <br>
        </div>
        <post-index user="<?php echo e(request()->user); ?>"></post-index>
    <?php else: ?>
        <div class="container">
            <div class="m-auto text-center border rounded p-3 bg-white">
                <p class="text-info font-italic">Random inspiring quote: </p>
                <p class="text-secondary font-italic"><?php echo e(\Illuminate\Foundation\Inspiring::quote()); ?></p>
            </div>
            <br>
        </div>
        <post-index></post-index>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/blog/resources/views/posts/index.blade.php ENDPATH**/ ?>