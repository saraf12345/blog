<?php $__env->startSection('content'); ?>

    <div class="container border p-4 bg-white">
        <div class="text-right">
            <a href="/posts/edit/<?php echo e($post->id); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <a href="/post-delete/<?php echo e($post->id); ?>" class="btn btn-sm btn-danger">Delete</a>
        </div>
        <h2 class="mb-0"><?php echo e($post->title); ?></h2>
        <small><?php echo e(Carbon\Carbon::parse($post->created_at)->format('M d, Y')); ?> | Category: <?php echo e($post->category->name); ?></small>

        <p class="mt-2"><?php echo e($post->body); ?></p>

        <br>
        <i class="fas fa-eye text-info"></i> Impressions: <?php echo e($post->impressions); ?>

        <hr>
        <h3>Comments</h3>
        <table class="table table-striped">
            <tbody>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="d-flex">
                    <td class="col-2">
                        <a class="text-info" href="/?user=<?php echo e($comment->name); ?>"><h5><?php echo e($comment->name); ?></h5></a>
                    </td>
                    <td class="col">
                        <b><?php echo e($comment->content); ?></b> <small><?php echo e(Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?></small>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if($post->can_comment): ?>
            <form method="post" action="/post/comment/<?php echo e($post->id); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-2 form-group mt-2">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>
                    <div class="col form-group mt-2">
                        <label for="comment">Comment</label>
                        <input type="text" name="comment" class="form-control">
                    </div>
                    <div class="co-1 mt-4">
                        <button class="btn btn-info mt-3">Comment</button>
                    </div>
                </div>
            </form>
        <?php else: ?>
            Comments are disabled for this post
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/blog/resources/views/posts/show.blade.php ENDPATH**/ ?>