<label for="">Name</label>
<input type="text">
<button>submit</button><?php /**PATH /Users/maksibajo/code/blog/resources/views/welcome.blade.php ENDPATH**/ ?>