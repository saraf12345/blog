<?php $__env->startSection('content'); ?>

    <div class="col m-auto p-4 border bg-white">
        <div class="text-center mb-4">
            <h1>  Edit post  </h1>
            <hr>
        </div>

        <form method="post">

            <?php echo e(csrf_field()); ?>


            <div class="form-label-group">
                <label for="title">Post title</label>
                <input type="text" name="title" class="form-control" placeholder="Post title" value="<?php echo e($post->title); ?>" required>
            </div>

            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="can_comment">Comments</label>
                        <select name="can_comment" class="form-control">
                            <option value="1" <?php if($post->can_comment): ?> selected <?php endif; ?>>Enabled</option>
                            <option value="0" <?php if(! $post->can_comment): ?> selected <?php endif; ?>>Disabled</option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="category_id">Category</label>
                        <select name="category_id" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if($category->id == $post->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-label-group">
                <label for="body">Post body</label>
                <textarea name="body" class="form-control" placeholder="Post body" rows="5"><?php echo e($post->body); ?></textarea>
            </div>

            <button class="btn btn-lg btn-info mt-4" type="submit">Update</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/blog/resources/views/posts/edit.blade.php ENDPATH**/ ?>