<?php

namespace App\Http\Controllers;

use App\Category;
use App\Post;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();

        return view('categories.index', compact('categories'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
        ]);

        $category = Category::create([
            'name' => $request->name,
        ]);

        return redirect()->back();
    }

    public function destroy($categoryId)
    {
        $category = Category::find($categoryId);

        foreach ($category->posts as $post) {
            Post::destroy($post->id);
        }
        Category::destroy($categoryId);
        return redirect()->back();
    }
}
