<?php

namespace App\Http\Controllers;

use App\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{

    public function create($postId, Request $request)
    {
        $this->validate($request, [
            'content' => 'required',
        ]);

        Comment::create([
            'name' => $request->name,
            'post_id' => $postId,
            'content' => $request->comment,
        ]);

        return back();
    }
}
