<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SessionController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest')->except('destroy');
    }

    public function login()
    {
        return view('sessions.login');
    }

    public function create()
    {
        if (!auth()->attempt(request(['email', 'password']))) {
            return back();
        }

        return redirect('/');
    }

    public function destroy()
    {
        auth()->logout();

        return redirect('login');
    }
}
