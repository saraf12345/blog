<?php

namespace App\Http\Controllers;

use App\Category;
use App\Comment;
use App\Post;
use App\User;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->only(['create', 'store']);
    }

    public function index(Request $request)
    {
        $post_array = [];
        if ($request->category) {
            if ($category = Category::where('name', '=', $request->category)->first()){
                $posts = $category->posts;
            } else {
                $posts = [];
            }
        } elseif ($request->user) {
            if ($user = User::where('name', '=', $request->user)->first()) {
                $posts = $user->posts;
            } else {
                $posts = [];
            }
        } else {
            $posts = Post::select('*')->orderBy('created_at', 'DESC')->get();
        }

        foreach ($posts as $post) {
            array_push($post_array, [
                'id' => $post->id,
                'title' => $post->title,
                'body' => $post->body,
                'user' => $post->user,
                'category' => $post->category,
                'created_at' => $post->created_at,
            ]);
        }
        return $posts;
    }

    public function show($postId)
    {
        $post = Post::find($postId);
        if (! auth()->user()) {
            $post->impressions++;
            $post->save();
        }
        $comments = $post->comments;

        return view('posts.show', compact(['post', 'comments']));
    }

    public function create()
    {
        return view('posts.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'body' => 'required',
        ]);

        $post = Post::create([
            'title' => $request->title,
            'body'  => $request->body,
            'category_id' => $request->category_id,
            'can_comment' => $request->can_comment,
        ]);

        return 'success';
    }

    public function edit($postId)
    {
        $post = Post::find($postId);
        $categories = Category::all();

        return view('posts.edit', compact(['post', 'categories']));
    }

    public function update($postId, Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'body' => 'required',
        ]);
        $post = Post::find($postId);
        $post->update([
            'title' => $request->title,
            'body' => $request->body,
            'can_comment' => $request->can_comment,
            'category_id' => $request->category_id,
        ]);

        return redirect()->back();
    }

    public function destroy($postId)
    {
        $post = Post::find($postId);
        foreach ($post->comments as $comment) {
            Comment::destroy($comment->id);
        }
        Post::destroy($postId);

        return redirect('/');
    }

    public function getCategories()
    {
        $categories = Category::all();

        return $categories;
    }
}
