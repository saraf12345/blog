@extends('layout.master')


@section('content')

    @if(request()->category)
        <div class="container">
            <div class="m-auto text-center border rounded p-3 bg-white">
                <p class="text-info font-italic">Posts of category: </p>
                <h1 class="text-secondary font-italic">{{ request()->category }}</h1>
            </div>
            <br>
        </div>
        <post-index category="{{ request()->category }}"></post-index>
    @elseif(request()->user)
        <div class="container">
            <div class="m-auto text-center border rounded p-3 bg-white">
                <p class="text-info font-italic">Posts of user: </p>
                <h1 class="text-secondary font-italic">{{ request()->user }}</h1>
            </div>
            <br>
        </div>
        <post-index user="{{ request()->user }}"></post-index>
    @else
        <div class="container">
            <div class="m-auto text-center border rounded p-3 bg-white">
                <p class="text-info font-italic">Random inspiring quote: </p>
                <p class="text-secondary font-italic">{{ \Illuminate\Foundation\Inspiring::quote() }}</p>
            </div>
            <br>
        </div>
        <post-index></post-index>
    @endif

@endsection
