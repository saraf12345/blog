@extends('layout.master')


@section('content')

    <div class="container border p-4 bg-white">
        <div class="text-right">
            <a href="/posts/edit/{{ $post->id }}" class="btn btn-sm btn-outline-secondary">Edit</a>
            <a href="/post-delete/{{ $post->id }}" class="btn btn-sm btn-danger">Delete</a>
        </div>
        <h2 class="mb-0">{{ $post->title }}</h2>
        <small>{{ Carbon\Carbon::parse($post->created_at)->format('M d, Y') }} | Category: {{ $post->category->name }}</small>

        <p class="mt-2">{{ $post->body }}</p>

        <br>
        <i class="fas fa-eye text-info"></i> Impressions: {{ $post->impressions }}
        <hr>
        <h3>Comments</h3>
        <table class="table table-striped">
            <tbody>
            @foreach($comments as $comment)
                <tr class="d-flex">
                    <td class="col-2">
                        <a class="text-info" href="/?user={{ $comment->name }}"><h5>{{ $comment->name }}</h5></a>
                    </td>
                    <td class="col">
                        <b>{{ $comment->content }}</b> <small>{{ Carbon\Carbon::parse($comment->created_at)->diffForHumans() }}</small>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        @if($post->can_comment)
            <form method="post" action="/post/comment/{{ $post->id }}">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-2 form-group mt-2">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>
                    <div class="col form-group mt-2">
                        <label for="comment">Comment</label>
                        <input type="text" name="comment" class="form-control">
                    </div>
                    <div class="co-1 mt-4">
                        <button class="btn btn-info mt-3">Comment</button>
                    </div>
                </div>
            </form>
        @else
            Comments are disabled for this post
        @endif
    </div>

@endsection