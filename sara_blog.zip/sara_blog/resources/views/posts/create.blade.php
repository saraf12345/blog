@extends('layout.master')


@section('content')

    <div class="col m-auto p-4 border bg-white">
        <div class="text-center mb-4">
            <h1>  Create post  </h1>
            <hr>
        </div>

        <form method="post">

            {{ csrf_field() }}

            <div class="row">
                <div class="col">
                    <div class="form-label-group">
                        <label for="title">Post title</label>
                        <input type="text" name="title" class="form-control" placeholder="Post title" required>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="category_id">Category</label>
                        <select name="category_id" class="form-control">
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-label-group">
                <label for="body">Post body</label>
                <textarea name="body" class="form-control" placeholder="Post body" rows="5"></textarea>
            </div>

            <button class="btn btn-lg btn-primary mt-4" type="submit">Post</button>
        </form>
    </div>

@endsection