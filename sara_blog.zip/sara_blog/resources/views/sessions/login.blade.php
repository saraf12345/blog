@extends('layout.master')


@section('content')

    <div class="col-6 m-auto border p-5 bg-white">
        <form class="form-signin" method="post">

            {{ csrf_field() }}

            <div class="text-center mb-4">
                <h1>  Login in  </h1>
                <hr>
            </div>

            <div class="form-label-group">
                <label for="email">Email address</label>
                <input type="email" name="email" class="form-control" placeholder="Email address" required>
            </div>

            <div class="form-label-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <button class="btn btn-lg btn-info btn-block mt-4" type="submit">Sign in</button>
        </form>
    </div>

@endsection