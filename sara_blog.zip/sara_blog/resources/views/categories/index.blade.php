@extends('layout.master')


@section('content')

    <div class="container p-4 border bg-white">

        <form action="/store/category">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-10">
                    <div class="form-group">
                        <label for="catgory">Add Category</label>
                        <input name="name" type="text" class="form-control">
                    </div>
                </div>
                <div class="col-2 pt-3">
                    <button class="btn btn-outline-info mt-3">Add</button>
                </div>
            </div>
        </form>
        <br>
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Category</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            @foreach($categories as $category)
                <tr>
                    <td>{{ $category->id }}</td>
                    <td>{{ $category->name }}</td>
                    <td><a class="btn btn-danger" href="/delete-category/{{ $category->id }}">Delete</a></td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

@endsection