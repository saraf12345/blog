/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */
import Vue from 'vue'
import VModal from 'vue-js-modal'

Vue.use(VModal)

require('./bootstrap');

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

window.Vue = Vue

const files = require.context('./', true, /\.vue$/i)
files.keys().map(key =>
    Vue.component(
        key
            .split('/')
            .pop()
            .split('.')[0],
        files(key).default
    )
)


function addElemWithDataAppToBody() {
    const app = document.createElement('div')
    app.setAttribute('data-app', true)
    document.body.append(app)
}

addElemWithDataAppToBody()
const app = new Vue({
    el: '#app',
})