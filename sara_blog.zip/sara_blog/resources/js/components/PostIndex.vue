<template>
    <div class="container p-4 border bg-white">
        <h1 class="text-muted text-center" v-if="posts.length === 0">Sorry
            <i class="fas fa-sad-tear text-warning bg-info p-0" style="border:2px solid grey; border-radius: 50%"></i><br>
            There are no posts in this page
        </h1>

        <div class="blog-post" v-for="post in posts">
            <div class="row">
                <div class="col">
                    <h2 class="mb-0">
                        <a class="text-info" :href="'/post/'+post.id">{{ post.title }}</a>
                    </h2>
                </div>
                <div class="col-1">
                    <i class="fas fa-eye text-info"></i> {{ post.impressions }}
                </div>
            </div>
            <small>
                {{ post.created_at }}
                | Category:
                <a class="text-info" :href="'/?category='+post.category.name">{{ post.category.name }}</a>
            </small>

            <p class="mt-2">{{ post.body }}</p>
            <hr>
        </div>
    </div>
</template>

<script>
    import CreatePost from "./CreatePost";
    export default {
        components: {CreatePost},
        props: ['category'],
        data(){
            return {
                posts: [],
            }
        },
        methods: {
            fetchAll() {
                var that = this
                axios.get('/api/posts').then(function (response) {
                    response.data.forEach(post => {
                        that.posts.push(post)
                    })
                })
            },
            fetchByCategory(category) {
                var that = this
                axios.get('/api/posts?category='+category).then(function (response) {
                    response.data.forEach(post => {
                        that.posts.push(post)
                    })
                })
            },
        },
        mounted() {
            if (this.category) {
                this.fetchByCategory(this.category)
            } else {
                this.fetchAll()
            }
        }
    }
</script>