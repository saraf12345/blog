<template>
    <div>
        <button class="btn btn-sm btn-outline-info" @click="showModal">Create Post</button>
        <modal
                name="create_post"
                height="auto"
                width="50%"
                :scrollable="true"
                :adaptive="true"
        >
            <div class="col m-auto p-5 border bg-white rounded">
                <div class="text-center mb-4">
                    <h1>  Create post  </h1>
                    <hr>
                </div>

                <form @submit.prevent="submit">
                    <div class="form-label-group">
                        <label for="title">Post title</label>
                        <input type="text" name="title" class="form-control" placeholder="Post title" v-model="resource.title" required>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="can_comment">Comments</label>
                                <select name="can_comment" class="form-control" v-model="resource.can_comment">
                                    <option value="1">Enabled</option>
                                    <option value="0">Disabled</option>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="category_id">Category</label>
                                <select name="category_id" class="form-control" v-model="resource.category_id">
                                    <option value="null" disabled>Select category</option>
                                    <option :value="category.id" v-for="category in categories">{{ category.name }}</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-label-group">
                        <label for="body">Post body</label>
                        <textarea name="body" class="form-control" placeholder="Post body" v-model="resource.body" rows="5"></textarea>
                    </div>

                    <button class="btn btn-lg btn-primary mt-4" type="submit">Post</button>
                </form>
            </div>

        </modal>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                categories: [],
                resource: {
                    category_id: null,
                    can_comment: 1,
                },
            }
        },
        methods: {
            showModal() {
                this.$modal.show('create_post')
            },
            closeModal() {
                this.$modal.hide('create_post')
            },
            submit() {
                var that = this
                axios.post('/api/posts/create', this.resource)
                    .then(function (response) {
                        that.closeModal()
                    })
                window.location = '/'
            },
            getCategories() {
                var that = this
                axios.get('/api/categories')
                    .then(function (response) {
                        that.categories = response.data
                    })
            }
        },
        mounted() {
            this.getCategories()
        }
    }
</script>
