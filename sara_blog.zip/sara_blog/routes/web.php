<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::view('/', 'posts.index')->name('home');
Route::get('api/posts', 'PostController@index');
Route::get('api/categories', 'PostController@getCategories');
Route::post('api/posts/create', 'PostController@store');

Route::get('/post/{postId}', 'PostController@show');
Route::get('/posts/create', 'PostController@create');
Route::get('/posts/edit/{postId}', 'PostController@edit');
Route::post('/posts/edit/{postId}', 'PostController@update');
Route::get('/post-delete/{postId}', 'PostController@destroy');
Route::post('/post/comment/{postId}', 'CommentController@create');

Route::get('/categories', 'CategoryController@index');
Route::get('/store/category', 'CategoryController@store');
Route::get('/delete-category/{categoryId}', 'CategoryController@destroy');


Route::get('/login', 'SessionController@login')->name('login');

Route::post('/login', 'SessionController@create');

Route::get('/logout', 'SessionController@destroy');



